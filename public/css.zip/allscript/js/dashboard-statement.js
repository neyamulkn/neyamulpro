(function($){
    $('.datepicker').datepicker();
})(jQuery);