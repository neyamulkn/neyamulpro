<?php
    require_once 'includes/header.php';
?>
<!--<link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>-->

<style>
    table, td, th{
        border:1px solid #ddd !important;
    }
</style>
<script>
	$( function() {
		$( "#startDate" ).datepicker({
			format: "<?php echo $dateformat; ?>",
			autoclose: true
		});
		
		$("#endDate").datepicker({
			format: "<?php echo $dateformat; ?>",
			autoclose: true
		});
	} );
</script>

<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
	<div class="row">
		<div class="col-lg-12">
			<h1 class="page-header">Manage Manufacturer</h1>
		</div>
	</div><!--/.row-->
	
	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-body">
					
					<?php
                        if (!empty($alert_msg)) {
                            $flash_status = $alert_msg[0];
                            $flash_header = $alert_msg[1];
                            $flash_desc = $alert_msg[2];

                            if ($flash_status == 'failure') {
                                ?>
							<div class="row" id="notificationWrp">
								<div class="col-md-12">
									<div class="alert bg-warning" role="alert">
										<i class="icono-exclamationCircle" style="color: #FFF;"></i> 
										<?php echo $flash_desc; ?> <i class="icono-cross" id="closeAlert" style="cursor: pointer; color: #FFF; float: right;"></i>
									</div>
								</div>
							</div>
					<?php	
                            }
                            if ($flash_status == 'success') {
                                ?>
							<div class="row" id="notificationWrp">
								<div class="col-md-12">
									<div class="alert bg-success" role="alert">
										<i class="icono-check" style="color: #FFF;"></i> 
										<?php echo $flash_desc; ?> <i class="icono-cross" id="closeAlert" style="cursor: pointer; color: #FFF; float: right;"></i>
									</div>
								</div>
							</div>
					<?php

                            }
                        }
                    ?>
					
					<div class="row">
						<div class="col-md-6">
							<a href="<?=base_url()?>expenses/addNewExpenses" style="text-decoration: none">
								<button class="btn btn-primary" style="padding: 0px 12px;"><i class="icono-plus"></i>
								Add Manufacturer Expense
								</button>
							</a>
						</div>
					
					</div><br/>
					
					<div class="row" style="margin-top: 0px;">
						<div class="col-md-12">
							
							<div class="table-responsive">
								<table class="table">
									<thead>
										<tr>
								    	<th width="10%">Date</th>
									    <th width="30%">Medichine Company</th>
									    <th width="10%">Debit</th>
									    <th width="10%">Cradit</th>
									    <th width="10%">Total</th>
									 
									    <th width="10%"><?php echo $lang_action; ?></th>
									</tr>
								    </thead>
									<tbody>
									<?php
                                        if (count($results) > 0) {
											
                                            foreach ($results as $data) {
                                                $id = $data->id;
                                                $medichine_id = $data->medichine_company;
                                                $outlet_id = $data->outlet_id;
                                                $date = date("$setting_dateformat", strtotime($data->date));
                                               
                                                $exp_cat_name = '';
                                                $expcomNameData = $this->Constant_model->getDataOneColumn('medichine_company', 'id', $medichine_id);
                                                if (count($expcomNameData) > 0) {
                                                    $exp_cat_name = $expcomNameData[0]->name;
                                                }
		
                                                $outlet_name = '';
                                                $outletNameData = $this->Constant_model->getDataOneColumn('outlets', 'id', $outlet_id);
                                                $outlet_name = $outletNameData[0]->name;
													
												?>
												<tr>
													<?php  
												 	    $total_debit = 0;
												 	    $total_cradit = 0;
													    $get_debit_cradit = $this->Constant_model->getDataOneColumn('expenses', 'medichine_company', "$medichine_id");
													    
													     for ($s = 0; $s < count($get_debit_cradit); ++$s) {
													        $total_debit += $get_debit_cradit[$s]->debit;
															$total_cradit += $get_debit_cradit[$s]->cradit;
															
													     }
													?>
													
													<td><?php echo $date; ?></td>
													<td><?php echo $exp_cat_name; ?></td>
													<td>&#x9f3; <?php echo $total_debit; ?></td>
													<td>&#x9f3; <?php echo $total_cradit; ?></td>
													<td>&#x9f3; <?php echo $total = $total_debit - $total_cradit; ?></td>
													<td>
													<a href="expense_details?id=<?php echo $medichine_id; ?>" style="text-decoration: none">
														<button class="btn btn-primary">&nbsp;&nbsp;Expenses Details &nbsp;&nbsp;</button>
													</a>
									
													</td>
												</tr>
										<?php

                                            }
                                        } else {
                                            ?>
											<tr class="no-records-found">
												<td colspan="5"><?php echo $lang_no_match_found; ?></td>
											</tr>
									<?php

                                        }
                                    ?>
									</tbody>
								</table>
							</div>
							
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-6" style="float: left; padding-top: 10px;">
							<?php echo $displayshowingentries; ?>
						</div>
						<div class="col-md-6" style="text-align: right;">
							<?php echo $links; ?>
						</div>
					</div>
					
				</div><!-- Panel Body // END -->
			</div><!-- Panel Default // END -->
		</div><!-- Col md 12 // END -->
	</div><!-- Row // END -->
	
	<br /><br /><br />
	
</div><!-- Right Colmn // END -->
	
	
	
<?php
    require_once 'includes/footer.php';
?>