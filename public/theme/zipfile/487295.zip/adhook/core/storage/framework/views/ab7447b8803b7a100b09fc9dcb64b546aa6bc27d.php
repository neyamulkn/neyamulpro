

<?php $__env->startSection('content'); ?>
<div class="tile">
  <div class="card card-body bg-dark">
    <div class="row">
      <div class="col-md-6 col-lg-3">
        <div class="widget-small primary coloured-icon"><i class="icon fa fa-users fa-3x"></i>
          <div class="info">
            <h4>Advertisers</h4>
            <p><b><?php echo e($users); ?></b></p>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-lg-3">
        <div class="widget-small danger coloured-icon"><i class="icon fa fa-bullhorn fa-3x"></i>
          <div class="info">
            <h4>Publishers</h4>
            <p><b><?php echo e($pub); ?></b></p>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-lg-3">
        <div class="widget-small info coloured-icon"><i class="icon fa fa-share fa-3x"></i>
          <div class="info">
            <h4>Withdraw Req</h4>
            <p><b><?php echo e($withdraw); ?></b></p>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-lg-3">
        <div class="widget-small warning coloured-icon"><i class="icon fa fa-plus fa-3x"></i>
          <div class="info">
            <h4>Total Deposit</h4>
            <p><b><?php echo e($deposit); ?></b> <?php echo e($gnl->cur); ?></p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="card card-body bg-dark">
    <div class="row">
      <div class="col-md-4">
        <div class="widget-small info coloured-icon"><i class="icon fa fa-image fa-3x"></i>
          <div class="info">
            <h4>Total Ads</h4>
            <p><b><?php echo e($ads); ?></b></p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="widget-small warning coloured-icon"><i class="icon fa fa-globe fa-3x"></i>
          <div class="info">
            <h4>Total Impression</h4>
            <p><b><?php echo e($views); ?></b></p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="widget-small primary coloured-icon"><i class="icon fa fa-mouse-pointer fa-3x"></i>
          <div class="info">
            <h4>Total Click</h4>
            <p><b><?php echo e($click); ?></b></p>
          </div>
        </div>
      </div>
      
    </div>
  </div>
</div>
<div class="tile">
  <h1 class="text-center">Advertisements</h1>
  <table class="table table-hover">
    <thead>
      <tr>
        <th>Ad Type</th>
        <th>Redirect URL</th>
        <th>Ad Type</th>
        <th>Estimated Amount</th>
        <th>Clicked</th>
        <th>Impression</th>
        <th>Status</th>
        <th>View</th>
      </tr>
    </thead>
    <tbody>
      <?php if(count($advertises)==0): ?> <h3>No Ads Available</h3> <?php endif; ?>
      <?php $__currentLoopData = $advertises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($ad->adtype->name); ?></td>
        <td><?php echo e($ad->link); ?></td>
        <td>
          <span class="badge <?php echo e($ad->click==1?'badge-success':'badge-info'); ?>"><?php echo e($ad->click==1?'Click':'Impression'); ?></span>
        </td>
        
        <td><?php echo e($ad->total); ?> <?php echo e($ad->click==1?'Click':'Impression'); ?></td>
        <td><?php echo e($ad->count_click); ?></td>
        <td><?php echo e($ad->count_imp); ?></td>
        <td>
          <span class="badge <?php echo e($ad->status==1?'badge-secondary':'badge-danger'); ?>">
            <?php echo e($ad->status==1?'Active':'Deactive'); ?>

          </span>
        </td>
        <td>
          <button class="btn btn-info btn-sm updButton" data-target="#updateModal" data-toggle="modal" data-photo="<?php echo e(asset('assets/images/ads')); ?>/<?php echo e($ad->photo); ?>" ><i class="fa fa-eye"></i> View</button>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php echo e($advertises->links()); ?>  
</div>
</div>
</div>



<!-- Update Modal -->
<div class="modal fade" id="updateModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content text-center">
      <div class="modal-header">
        <h5 class="modal-title" id="ModalTitle"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <img id="uploadedImageu"  alt="your image" style="width:100%;"/>    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<script>
  
  $(document).ready(function(){
    
    $(document).on('click','.updButton', function(){
      $('#ModalTitle').text($(this).data('name'));
      var photo =  $(this).data('photo')
      $('#uploadedImageu').attr('src',photo);
      
      
    });
    
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>