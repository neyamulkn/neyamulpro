

<?php $__env->startSection('content'); ?>
<section class="breadcrumb-area breadcrumb-bg white-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-inner">
                    <h1 class="title"><?php echo e($pt); ?></h1>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="testimonial-page-conent">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <table class="table table-hover text-center">
                    <thead>
                        <tr>
                            <th class="text-center">Amount</th>
                            <th class="text-center">Balance</th>
                            <th class="text-center">Details</th>
                            <th class="text-center">Trx ID</th>
                            <th class="text-center">Trx Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($logs)==0): ?> 
                        <tr>
                            <td colspan="5"><h2>No Data Available</h2></td>
                        </tr>
                        <?php endif; ?>
                        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="<?php echo e($log->type==1?'text-success':'text-danger'); ?>">
                            <td><?php echo e($log->amount); ?> <?php echo e($gnl->cur); ?></td>
                            <td><?php echo e(round($log->balance,$gnl->decimal)); ?> <?php echo e($gnl->cur); ?></td>
                            <td><?php echo e($log->details); ?></td>
                            <td><?php echo e($log->trxid); ?></td>
                            <td><?php echo e($log->created_at); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    
                </table>
                <?php echo e($logs->links()); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>