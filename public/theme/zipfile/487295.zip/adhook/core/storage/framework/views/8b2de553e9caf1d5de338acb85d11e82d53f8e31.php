<?php $__env->startSection('page_styles'); ?>
<script type="text/javascript" src="<?php echo e(asset('assets/admin/js/nicEdit-latest.js')); ?>"></script>
<script type="text/javascript">bkLib.onDomLoaded(nicEditors.allTextAreas);</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="tile">
    <div class="row">
        <div class="col-md-12">
            
            
            <form role="form" method="POST" action="<?php echo e(route('admin.footer-update')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                
                <div class="form-group">
                    <h4>Contact Number</h4>
                    <input type="text" value="<?php echo e($front->contact_number); ?>" class="form-control" id="contact_number" name="contact_number" >
                </div>
                <div class="form-group">
                    <h4>Contact Email</h4>
                    <input type="text" value="<?php echo e($front->contact_email); ?>" class="form-control" id="contact_email" name="contact_email" >
                </div>   
                
                <div class="form-group">
                    <h4>Contact Address</h4>
                    <textarea class="form-control" id="contact_address" name="contact_address" rows="7"><?php echo e($front->contact_address); ?></textarea>
                </div>								
                <div class="form-group">
                    <h4>Footer Section Content</h4>
                    <textarea class="form-control" id="footer" name="footer" rows="7"><?php echo e($front->footer); ?></textarea>
                </div>								
                
                
                <div class="form-group">
                    <button type="submit" class="btn btn-success btn-block">Update</button>
                </div>
                
            </form>
            
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>