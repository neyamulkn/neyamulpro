

<?php $__env->startSection('content'); ?>

<section class="breadcrumb-area breadcrumb-bg white-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-inner">
                    <h1 class="title"><?php echo e($pt); ?></h1>
                    <h4>Balance : <strong><?php echo e(round(Auth::user()->balance,$gnl->decimal)); ?> <?php echo e($gnl->cur); ?></strong></h4> 
                    <?php echo $__env->make('layouts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="testimonial-page-conent">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header text-center">Deposit Methods</div>
                    <div class="card-body">
                        <div class="row">
                            <?php $__currentLoopData = $gates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $gate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 mt-2">
                                <div class="card">
                                    <div class="card-header text-center"><?php echo e($gate->name); ?></div>
                                    <div class="card-body">
                                        <ul class="list-group text-center">
                                            <li class="list-group-item">
                                                <img src="<?php echo e(asset('assets/images/gateway')); ?>/<?php echo e($gate->id); ?>.jpg" style="width:100%;"/>
                                            </li>
                                            <li class="list-group-item">
                                                Limit: <strong><?php echo e($gnl->cursym); ?><?php echo e($gate->minamo); ?></strong> ~ <strong><?php echo e($gnl->cursym); ?><?php echo e($gate->maxamo); ?></strong>
                                            </li>
                                            <li class="list-group-item">
                                                Charge: <strong><?php echo e($gnl->cursym); ?><?php echo e($gate->fixed_charge); ?></strong> + <strong><?php echo e($gate->percent_charge); ?> %</strong>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="card-footer">
                                        <button data-toggle="modal" data-name="<?php echo e($gate->name); ?>" data-gate="<?php echo e($gate->id); ?>"  data-target="#depoModal" class="submit-btn depoButton" style="width:100%;">
                                            Deposit Now
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-12 mx-auto mt-3">
                <hr>
                <h3 class="text-center">Deposits</h3>
                <div style="overflow-x:auto;">
                    <table class="table table-hover text-center">
                        <thead>
                            <tr>
                                <th class="text-center">Amount</th>
                                <th class="text-center">Gateway</th>
                                <th class="text-center">TRX ID</th>
                                <th class="text-center">TRX Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($deposit)==0): ?> 
                            <tr>
                                <td colspan="4"><h2>No Data Available</h2></td>
                            </tr>
                            <?php endif; ?>
                            <?php $__currentLoopData = $deposit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($log->amount); ?> <?php echo e($gnl->cur); ?></td>
                                <td><?php echo e($log->gateway->name); ?></td>
                                <td><?php echo e($log->trx); ?></td>
                                <td><?php echo e($log->created_at); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        
                    </table>
                    <?php echo e($deposit->links()); ?>

                </div>
            </div>
        </div>
    </div>
</section>

<!-- Modal -->
<div class="modal fade" id="depoModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content text-center">
            <div class="modal-header">
                <h5 class="modal-title" id="ModalLabel"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('deposit.data-insert')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="gateway" id="gateWay"/>
                    <div class="form-group">
                        <h5>Enter Deposit Amount</h5>
                        <div class="input-group-append">
                            <input type="text" name="amount" class="form-control"/>                            
                            <span class="input-group-text"><?php echo e($gnl->cur); ?></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="submit-btn" style="width:100%;">Deposit Preview</button>
                        
                    </div>
                    
                </form>
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_scripts'); ?>
<script>
    $(document).ready(function(){
        $(document).on('click','.depoButton', function(){
            $('#ModalLabel').text($(this).data('name'));
            $('#gateWay').val($(this).data('gate'));
        });
    });
</script>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>