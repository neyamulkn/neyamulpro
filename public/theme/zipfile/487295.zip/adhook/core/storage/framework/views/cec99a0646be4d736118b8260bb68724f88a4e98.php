<!DOCTYPE html>
<html lang="en">

<head>
<title><?php echo e($gnl->title); ?> - Admin</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/images/logo/icon.png')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin/css/main.css')); ?>"> <?php echo $__env->yieldContent('page_styles'); ?>
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body class="app sidebar-mini rtl">
<header class="app-header">
<a class="app-header__logo" href="<?php echo e(route('admin.dashboard')); ?>">
<img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" alt="logo" class="logo-default" style="width: 160px; height: 20px;"> </a>
<a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
<ul class="app-nav">
<li class="dropdown">
<a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu">
<span><?php echo e(Auth::guard('admin')->user()->name); ?></span> <i class="fa fa-user fa-lg"></i>
</a>
<ul class="dropdown-menu settings-menu dropdown-menu-right">
<li><a class="dropdown-item" href="<?php echo e(route('admin.new-admin')); ?>"><i class="fa fa-user fa-lg"></i>Create New Admin </a></li>
<li><a class="dropdown-item" href="<?php echo e(route('admin.list-admin')); ?>"><i class="fa fa-users fa-lg"></i>List of Admin </a></li>
<li><a class="dropdown-item" href="<?php echo e(route('admin.change-password')); ?>"><i class="fa fa-cog fa-lg"></i> Change Password </a></li>

<li>
<a class="dropdown-item" href="#" onclick="event.preventDefault();
document.getElementById('logout-form').submit();">
<i class="fa fa-sign-out fa-lg"></i> Logout
</a>

<form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: none;">
<?php echo csrf_field(); ?>
</form>
</li>
</ul>
</li>
</ul>
</header>
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
<ul class="app-menu">
<li>
<a class="app-menu__item <?php if(request()->path() == 'admin/dashboard'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.dashboard')); ?>">
<i class="app-menu__icon fa fa-dashboard"></i>
<span class="app-menu__label">Dashboard</span></a>
</li>
<li class="treeview <?php if(request()->path() == 'admin/users'): ?> is-expanded
<?php elseif(request()->path() == 'admin/user-search'): ?> is-expanded
<?php elseif(request()->path() == 'admin/user-banned'): ?> is-expanded
<?php endif; ?>">
<a class="app-menu__item" href="#" data-toggle="treeview">
<i class="app-menu__icon fa fa-users"></i>
<span class="app-menu__label">Manage Advertisers</span>
<i class="treeview-indicator fa fa-angle-right"></i>
</a>
<ul class="treeview-menu">
<li>
<a class="treeview-item  <?php if(request()->path() == 'admin/users'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.users')); ?>">
<i class="icon fa fa-users"></i> All Advertisers</a>
</li>

<li>
<a class="treeview-item <?php if(request()->path() == 'admin/user-banned'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.user-ban')); ?>">
<i class="icon fa fa-users" style="color:brown;"></i> Banned Advertisers</a>
</li>

</ul>
</li>
<li class="treeview <?php if(request()->path() == 'admin/publishers'): ?> is-expanded
<?php elseif(request()->path() == 'admin/publisher-search'): ?> is-expanded
<?php elseif(request()->path() == 'admin/publisher-banned'): ?> is-expanded
<?php endif; ?>">
<a class="app-menu__item" href="#" data-toggle="treeview">
<i class="app-menu__icon fa fa-bullhorn"></i>
<span class="app-menu__label">Manage Publishers</span>
<i class="treeview-indicator fa fa-angle-right"></i>
</a>
<ul class="treeview-menu">
<li>
<a class="treeview-item  <?php if(request()->path() == 'admin/publishers'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.publishers')); ?>">
<i class="icon fa fa-users"></i> All Publishers</a>
</li>
<li>
<a class="treeview-item <?php if(request()->path() == 'admin/publisher-banned'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.publisher-ban')); ?>">
<i class="icon fa fa-users" style="color:brown;"></i> Banned Publishers</a>
</li>
</ul>
</li>
<li>
<a class="app-menu__item <?php if(request()->path() == 'admin/broadcast'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.broadcast')); ?>">
<i class="app-menu__icon fa fa-envelope"></i> <span class="app-menu__label">Broadcast Email</span></a>
</li>
<li>
<a class="app-menu__item <?php if(request()->path() == 'admin/subscribers'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.subscribers')); ?>">
<i class="app-menu__icon fa fa-file"></i> <span class="app-menu__label">Subscribers</span></a>
</li>
<li class="treeview
<?php if(request()->path() == 'admin/ad-types'): ?>  is-expanded
<?php elseif(request()->path() == 'admin/plans'): ?>  is-expanded
<?php endif; ?>">
<a class="app-menu__item" href="#" data-toggle="treeview">
<i class="app-menu__icon fa fa-picture-o"></i>
<span class="app-menu__label">Advertisements</span>
<i class="treeview-indicator fa fa-angle-right"></i>
</a>
<ul class="treeview-menu">
<li>
<a class="treeview-item  <?php if(request()->path() == 'admin/plans'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.plans')); ?>">
<i class="icon fa fa-cube"></i>Plans</a>
</li>
<li>
<a class="treeview-item  <?php if(request()->path() == 'admin/ad-types'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.adtypes')); ?>">
<i class="icon fa fa-picture-o"></i>Types</a>
</li>
</ul>
</li>
<li class="treeview
<?php if(request()->path() == 'admin/deposits'): ?>  is-expanded
<?php elseif(request()->path() == 'admin/gateway'): ?>  is-expanded
<?php endif; ?>">
<a class="app-menu__item" href="#" data-toggle="treeview">
<i class="app-menu__icon fa fa-plus"></i>
<span class="app-menu__label">Deposit</span>
<i class="treeview-indicator fa fa-angle-right"></i>
</a>
<ul class="treeview-menu">
<li>
<a class="treeview-item  <?php if(request()->path() == 'admin/deposits'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.deposits')); ?>">
<i class="icon fa fa-list"></i> Deposits</a>
</li>
<li>
<a class="treeview-item <?php if(request()->path() == 'admin/gateway'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.gateway')); ?>">
<i class="icon fa fa-credit-card"></i> Payment Gateway</a>
</li>
</ul>
</li>
<li class="treeview
<?php if(request()->path() == 'admin/withdraw-request'): ?> is-expanded
<?php elseif(request()->path() == 'admin/wmethod'): ?> is-expanded
<?php elseif(request()->path() == 'admin/withdraw-log'): ?> is-expanded <?php endif; ?>">
<a class="app-menu__item" href="#" data-toggle="treeview">
<i class="app-menu__icon fa fa-share"></i>
<span class="app-menu__label">Withdraw</span>
<i class="treeview-indicator fa fa-angle-right"></i>
</a>
<ul class="treeview-menu">
<li>
<a class="treeview-item  <?php if(request()->path() == 'admin/withdraw-request'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.withdraw-request')); ?>">
<i class="icon fa fa-share"></i> Withdraw Request</a>
</li>
<li>
<a class="treeview-item <?php if(request()->path() == 'admin/withdraw-log'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.withdraw-log')); ?>">
<i class="icon fa fa-list"></i> Withdraw Log</a>
</li>
<li>
<a class="treeview-item <?php if(request()->path() == 'admin/wmethod'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.wmethod')); ?>">
<i class="icon fa fa-credit-card"></i> Withdraw Method</a>
</li>
</ul>
</li>
<li class="treeview
<?php if(request()->path() == 'admin/general'): ?> is-expanded
<?php elseif(request()->path() == 'admin/logo-icon'): ?> is-expanded
<?php elseif(request()->path() == 'admin/email-sms'): ?> is-expanded <?php endif; ?>">
<a class="app-menu__item" href="#" data-toggle="treeview">
<i class="app-menu__icon fa fa-cogs"></i>
<span class="app-menu__label">Website Control</span>
<i class="treeview-indicator fa fa-angle-right"></i>
</a>
<ul class="treeview-menu">
<li>
<a class="treeview-item  <?php if(request()->path() == 'admin/general'): ?> active  <?php endif; ?> " href="<?php echo e(route('admin.general')); ?>">
<i class="icon fa fa-cog"></i> General Settings</a>
</li>
<li>
<a class="treeview-item <?php if(request()->path() == 'admin/logo-icon'): ?> active  <?php endif; ?>" href="<?php echo e(route('admin.logo')); ?>">
<i class="icon fa fa-picture-o"></i> Logo and Icon</a>
</li>
<li>
<a class="treeview-item <?php if(request()->path() == 'admin/eamil-sms'): ?> active <?php endif; ?>" href="<?php echo e(route('admin.email')); ?>">
<i class="icon fa fa-envelope"></i> Email and SMS</a>
</li>
</ul>
</li>
<li class="treeview
<?php if(request()->path() == 'admin/about-section'): ?> is-expanded
<?php elseif(request()->path() == 'admin/banner-section'): ?> is-expanded
<?php elseif(request()->path() == 'admin/service-section'): ?> is-expanded
<?php elseif(request()->path() == 'admin/testimonial-section'): ?> is-expanded
<?php elseif(request()->path() == 'admin/footer-section'): ?> is-expanded
<?php elseif(request()->path() == 'admin/social-section'): ?> is-expanded
<?php elseif(request()->path() == 'admin/faq-section'): ?> is-expanded
<?php elseif(request()->path() == 'admin/stat-section'): ?> is-expanded
<?php elseif(request()->path() == 'admin/blog-section'): ?> is-expanded
<?php elseif(request()->path() == 'admin/blog-create'): ?> is-expanded
<?php endif; ?>">
<a class="app-menu__item" href="#" data-toggle="treeview">
<i class="app-menu__icon fa fa-globe"></i>
<span class="app-menu__label">Frontend Content</span>
<i class="treeview-indicator fa fa-angle-right"></i>
</a>
<ul class="treeview-menu">
<li>
<a class="treeview-item  <?php if(request()->path() == 'admin/banner-section'): ?> active  <?php endif; ?> " href="<?php echo e(route('admin.bannersection')); ?>">
<i class="icon fa fa-cog"></i> Banner Section</a>
</li>
<li>
<a class="treeview-item  <?php if(request()->path() == 'admin/service-section'): ?> active  <?php endif; ?> " href="<?php echo e(route('admin.slidersection')); ?>">
<i class="icon fa fa-cog"></i> Service Section</a>
</li>
<li>
<a class="treeview-item  <?php if(request()->path() == 'admin/about-section'): ?> active  <?php endif; ?> " href="<?php echo e(route('admin.aboutsection')); ?>">
<i class="icon fa fa-cog"></i> About Section</a>
</li>
<li>
<a class="treeview-item  <?php if(request()->path() == 'admin/testimonial-section'): ?> active  <?php endif; ?> " href="<?php echo e(route('admin.testimonialsection')); ?>">
<i class="icon fa fa-cog"></i> Testimonial Section</a>
</li>
<li>
<a class="treeview-item  <?php if(request()->path() == 'admin/stat-section'): ?> active  <?php endif; ?> " href="<?php echo e(route('admin.statsection')); ?>">
<i class="icon fa fa-cog"></i> Statistics Section</a>
</li>
<li>
<a class="treeview-item  <?php if(request()->path() == 'admin/faq-section'): ?> active  <?php endif; ?> " href="<?php echo e(route('admin.faqsection')); ?>">
<i class="icon fa fa-cog"></i> FAQ Section</a>
</li>
<li>
<a class="treeview-item  <?php if(request()->path() == 'admin/footer-section'): ?> active  <?php endif; ?> " href="<?php echo e(route('admin.footersection')); ?>">
<i class="icon fa fa-cog"></i> Footer Section</a>
</li>
<li>
    <a class="treeview-item  <?php if(request()->path() == 'admin/blog-section'): ?> active <?php elseif(request()->path() == 'admin/blog-create'): ?> active  <?php endif; ?> " href="<?php echo e(route('admin.blogsection')); ?>">
    <i class="icon fa fa-cog"></i> Blog Section</a>
    </li>
<li>
<a class="treeview-item  <?php if(request()->path() == 'admin/social-section'): ?> active  <?php endif; ?> " href="<?php echo e(route('admin.socialsection')); ?>">
<i class="icon fa fa-cog"></i> Social Section</a>
</li>


</ul>
</li>
</ul>
</aside>
<main class="app-content">
<div class="app-title">
<div>
<h1 style="text-transform:uppercase;"><i class="fa fa-dashboard"></i> <?php echo e($pt); ?></h1>
</div>
<div class="app-search">
<?php echo $__env->yieldContent('right_action'); ?>
</div>
</div>
<div class="row">
<div class="col-md-12">
<?php echo $__env->make('layouts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> <?php echo $__env->yieldContent('content'); ?>
</div>
</div>
</main>
<script src="<?php echo e(asset('assets/admin/js/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/plugins/pace.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/plugins/bootstrap-notify.min.js')); ?>"></script>
<?php echo $__env->yieldContent('page_scripts'); ?> 
<?php echo $__env->make('layouts.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>