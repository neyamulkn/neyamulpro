
<?php $__env->startSection('page_styles'); ?>
<script type="text/javascript" src="<?php echo e(asset('assets/admin/js/nicEdit-latest.js')); ?>"></script>
<script type="text/javascript">bkLib.onDomLoaded(nicEditors.allTextAreas);</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="tile">
    <div class="row">
        <div class="col-md-12">
            <form role="form" method="POST" action="<?php echo e(route('admin.banner-update')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="form-group col-md-12">
                        <h4>Section Heading</h4>
                        <input type="text" value="<?php echo e($front->banner_heading); ?>" class="form-control" id="banner_heading" name="banner_heading" >
                    </div>
                    <div class="form-group col-md-12">
                        <h4>Section Details</h4>
                        <textarea class="form-control" id="banner_details" name="banner_details" rows="7"> <?php echo e($front->banner_details); ?></textarea>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 card card-body">
                        <h4>Banner Photo</h4>
                        <div class="form-group">
                            <img  id="uploadedImage"  src="<?php echo e(asset('assets/user/img/bg/header-bg.png')); ?>" style="width:100%"   />
                        </div>
                        <div class="form-group">
                            <input type="file" class="form-control" name="banner_image" onchange="readURL(this);"> 
                        </div>                                    
                    </div>
                    <div class="col-md-6 card card-body">
                        <h4>Breadcrumb Photo</h4>
                        <div class="form-group">
                            <img  id="uploadedImage2"  src="<?php echo e(asset('assets/user/img/bg/breadcrumb-bg.png')); ?>" style="width:100%"  />
                        </div>
                        <div class="form-group">
                            <input type="file" class="form-control" name="bread" onchange="readURL2(this);"> 
                        </div>                                    
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-12">
                        <hr>
                        <button type="submit" class="btn btn-lg btn-success btn-block">Update</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_scripts'); ?>
<script>
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#uploadedImage').attr('src', e.target.result);
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
    function readURL2(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#uploadedImage2').attr('src', e.target.result);
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>