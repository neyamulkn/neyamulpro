<?php $__env->startSection('content'); ?>
<section class="breadcrumb-area breadcrumb-bg white-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-inner">
                    <h1 class="title"><?php echo e($pt); ?></h1>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="testimonial-page-conent">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6">
                <div class="single-testimonial-item">
                    <div class="img-wrapper">
                        <div class="icon big-dash-icon"><i class="fa fa-globe"></i></div>
                    </div>
                    <div class="content">
                        <h6>Total Impression</h6>
                        <h2><?php echo e($impression); ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="single-testimonial-item">
                    <div class="img-wrapper">
                        <div class="icon big-dash-icon"><i class="fa fa-hand-point-up"></i></div>
                    </div>
                    <div class="content">
                        <h6>Total Clicked</h6>
                        <h2><?php echo e($click); ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="single-testimonial-item">
                    <div class="img-wrapper">
                        <div class="icon big-dash-icon"><i class="fa fa-wallet"></i></div>
                    </div>
                    <div class="content">
                        <h6>Earnings</h6>
                        <h2><?php echo e(round(Auth::guard('publisher')->user()->balance,$gnl->decimal)); ?> <span style="font-size:15px;"><?php echo e($gnl->cur); ?></span></h2>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-12">
                <hr>
                <div class="card">
                    <div class="card-header text-center">
                        Withdraw Log
                    </div>
                    <div class="card-body">
                        <table class="table table-hover text-center">
                            <thead>
                                <tr>
                                    <th class="text-center">Amount</th>
                                    <th class="text-center">Method</th>
                                    <th class="text-center">Account</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Trx Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($withds)==0): ?> 
                                <tr>
                                    <td colspan="5"><h2>No Data Available</h2></td>
                                </tr>
                                <?php endif; ?>
                                <?php $__currentLoopData = $withds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($log->amount); ?> <?php echo e($gnl->cur); ?></td>
                                    <td><?php echo e($log->wmethod->name); ?></td>
                                    <td><?php echo e($log->account); ?></td>
                                    <td>
                                        <span class="badge <?php if($log->status==1): ?> badge-success <?php elseif($log->status==2): ?> badge-danger <?php else: ?> label-warning <?php endif; ?>">
                                            <?php if($log->status==1): ?>Approved <?php elseif($log->status==2): ?>Canceled <?php else: ?> Pending <?php endif; ?> 
                                        </span>
                                    </td>
                                    <td><?php echo e($log->updated_at); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            
                        </table>
                        <?php echo e($withds->links()); ?>

                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>