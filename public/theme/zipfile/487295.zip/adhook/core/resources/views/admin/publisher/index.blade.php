@extends('layouts.admin')
@section('right_action')
<form method="POST" action="{{route('admin.search-publishers')}}">
    @csrf
    <input type="search" name="search" class="app-search__input" style="background:#ddd;" placeholder="Search">
    <button class="app-search__button" type="submit"> <i class="fa fa-search"></i></button>
</form>
@endsection
@section('content')
<div class="tile">
    <table class="table table-hover">
        <thead>
            <tr>
                <th>
                    Name 
                </th>
                <th>
                    Email
                </th>
                <th>
                    Username
                </th>
                <th>
                    Phone
                </th>                       
                <th>
                    Details
                </th>
            </tr>
        </thead>
        <tbody>
            @foreach($users as $user)
            <tr>
                <td>
                    {{$user->name}}
                </td>
                <td>
                    {{$user->email}}      
                </td> 
                <td>
                    {{$user->username}}      
                </td>
                <td>
                    {{$user->mobile}}
                </td>
                <td>
                <a href="{{route('admin.publisher-single', $user->id)}}" class="btn btn-sm btn-info">
                        <i class="fa fa-eye"></i> View </a>
                    </td>
                </tr>
                @endforeach 
                <tbody>
                </table>
                {{$users->links()}}
            </div>      
            @endsection