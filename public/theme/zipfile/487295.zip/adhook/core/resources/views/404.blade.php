@extends('layouts.user')

@section('content')
<section class="breadcrumb-area breadcrumb-bg white-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-inner">
                    <h1 class="title">Page Not Found</h1>
                    <a href="{{route('home')}}" class="backtohome">Back To Home</a>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection