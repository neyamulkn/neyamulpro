@extends('layouts.user')

@section('content')
<section class="breadcrumb-area breadcrumb-bg white-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-inner">
                        <h1 class="title">Blog Post</h1>
                    </div>
                </div>
            </div>
        </div>
    </section>

<div class="blog-details-page-conent">
        <div class="container">
            <div class="row">
               <div class="col-lg-12 single-blog-details-inner-wrapper">
                    <div class="single-blog-details-post"><!-- single blog page -->
                        <div class="thumb">
                            <img src="{{ asset('assets/images/blog') }}/{{$post->photo}}" style="width:100%;" alt="blog images">
                        </div>
                        <div class="content">
                            <h4 class="title">{{$post->heading}}</h4>
                            <div class="post-meta">
                                <span class="time"><i class="far fa-clock"></i> {{$post->created_at}}</span>
                            </div>
                            <p>{!!$post->details!!}</p>
                        </div>
                    </div>
                    
               </div>
            </div>
        </div>
    </div>

    @endsection